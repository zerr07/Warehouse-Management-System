<?php
if (! (isset($_COOKIE['Authenticated']))){
    header("Location: /");
}