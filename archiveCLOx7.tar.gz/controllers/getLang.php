<?php
$lang = $_COOKIE['lang'];
$get_lang = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*languages*} WHERE lang='$lang'"));
$langID = $get_lang->fetch_assoc()['id'];