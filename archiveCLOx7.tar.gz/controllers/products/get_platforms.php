<?php
function get_platforms(){
    $arr = array();
    $query = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*platforms*}"));
    while ($row = mysqli_fetch_assoc($query)) {
        $arr[$row['id']] = $row;
    }
    return $arr;
}