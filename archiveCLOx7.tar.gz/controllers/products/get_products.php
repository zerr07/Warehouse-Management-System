<?php
include_once($_SERVER["DOCUMENT_ROOT"].'/controllers/getLang.php');
include_once($_SERVER["DOCUMENT_ROOT"].'/controllers/products/get_platforms.php');
include_once($_SERVER["DOCUMENT_ROOT"].'/controllers/products/applyRule.php');

function get_product_range($page, $status){
    global $search;
    $onPage = _ENGINE['onPage'];
    $start = $page*$onPage;
    if ($status == "Search"){
        return /** @lang text */ "SELECT COUNT(*) as count FROM {*products*} $search";
    }
    $result = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*products*} $search
                                                       ORDER BY id DESC LIMIT $start, $onPage"));
    if($result){
        return read_result_multiple($result);
    }
    return null;
}

function get_products(){
    $result = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*products*}"));
    if($result){
        return read_result_multiple($result);
    }
    return null;
}
function get_product($index){
    $result = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*products*} 
                                                                                    WHERE id='$index'"));
    if($result){
        while ($row = $result->fetch_assoc()) {
            return read_result_single($row);
        }
    }
    return null;
}
function read_result_multiple($result){
    global $langID, $lang;
    $arr = array(array());
    while ($row = $result->fetch_assoc()){
        $id = $row['id'];
        $arr[$id] = read_result_single($row);

    }
    return $arr;
}
function read_result_single($row){
    global $langID, $lang;

        $id = $row['id'];
        $arr = $row;
        $arr = array_merge($arr, get_locations($id));
        $arr['suppliers'] = get_supplier_data($id);
        $arr['platforms'] = get_platform_data($id);
        $arr['descriptions'] = get_desc($id);
        $arr['images'] = get_images($id);
        $arr['mainImage'] = get_main_image($id);
        /*$get_name = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */
            /*"SELECT * FROM {*product_name*} WHERE productID='$id' AND langID='$langID'"));
        while ($row_name = $get_name->fetch_assoc()){
            $arr[$id]['name'] = $row_name['product_name'];
            $arr[$id]['url'] = $row_name['url'];
        }
        $get_tag = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */
            /*"SELECT * FROM {*product_tags*} WHERE productID='$id' AND langID='$langID'"));
        while($row_tag = $get_tag->fetch_assoc()){
            $arr[$id]['tags'][$row_tag['id']] = $row_tag['tag'];
        }
        $translations = json_decode( file_get_contents($_SERVER["DOCUMENT_ROOT"].'/translations/products/'.$id.'.json'),
            true);
        $arr[$id]['misc'] = $translations['product'][$lang];
        $arr[$id]['misc']['description'] = html_entity_decode($arr[$id]['misc']['description']);
        if (!is_null($row['id_brand'])){
            $brand = $row['id_brand'];
            $get_brand = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */
                /*"SELECT * FROM {*brands*} WHERE id='$brand'"));
            $arr[$id]['brand'] = $get_brand->fetch_assoc()['brand_name'];
        }
        $arr[$id]['combinations'] = get_combination($id);*/
        return $arr;
}

function get_locations($index){
    $arr = array();
    $arr['locationList'] = array();
    $query = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*product_locations*}
        WHERE id_item='$index'"));
    while ($row = mysqli_fetch_assoc($query)) {

        array_push($arr['locationList'], $row['location']);
        $arr['locations'] .= " " . $row['location'];
    }
    return $arr;
}

function get_supplier_data($index){
    $arr = array();
    $query = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*supplier_data*}
        WHERE id_item='$index'"));
    while ($row = mysqli_fetch_assoc($query)) {
        $arr[$row['id']] = $row;
    }
    return $arr;
}
function get_platform_data($index){
    $arr = array();
    $platforms = get_platforms();
    foreach ($platforms as $platform){
        $id = $platform['id'];
        $query = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT id, URL, price, profit 
        FROM {*product_platforms*} WHERE id_item='$index' AND id_platform='$id'"));
        while ($row = mysqli_fetch_assoc($query)) {
            $arr[$id] = $row;
        }
    }
    $arr[2]['price'] = applyRule($index, 2, 2);
    return $arr;
}

function get_desc($index){
    $arr = array();
    $desc = json_decode( file_get_contents(
        $_SERVER["DOCUMENT_ROOT"].'/translations/products/items/'.$index.'.json'), true);
    $get_lang = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*languages*}"));
    while ($row = mysqli_fetch_assoc($get_lang)){
        $arr[$row['lang']] = html_entity_decode($desc['product'][$row['lang']]['description']);
    }
    return $arr;
}

function get_images($index){
    $arr = array(array());
    $q = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT id, image, `primary` 
                                                                FROM {*product_images*} WHERE id_item='$index'"));
    while ($row = mysqli_fetch_assoc($q)){
        $arr[$row['id']] = $row;
    }
    return array_filter($arr);
}

function get_main_image($index){
    $arr = array();
    $q = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT image
                                FROM {*product_images*} WHERE id_item='$index' AND `primary`=1"));
    if (mysqli_num_rows($q) == 0){
        $q = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT image 
                                FROM {*product_images*} WHERE id_item='$index' AND `primary`=0 LIMIT 1"));
    }
    while ($row = mysqli_fetch_assoc($q)){
        return $row['image'];
    }
}

$search = "";

if (isset($_GET['searchTagID'])) {
    if ($_GET['searchTagID'] != "") {
        $tagID = $_GET['searchTagID'];
        $q = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT id FROM products WHERE tag='$tagID'"));
        while ($row = mysqli_fetch_assoc($q)) {
            $id = $row['id'];
            header("Location: /cp/SupplierManageTool/view/?view=$id");
        }
    }
}
if (isset($_GET['searchName'])){
    $search = "WHERE";
    $searchString = htmlentities($_GET['searchName'], ENT_QUOTES, "UTF-8");
    $searchString = explode(" ", $searchString);
    $c = 0;
    foreach ($searchString as $str){
        if ($c == 0){
            $search .= " `name` LIKE '%".$str."%'";
        } else {
            $search .= " AND `name` LIKE '%".$str."%'";
        }
        $c++;
    }
}
if (isset($_POST['cat'])){
    $cat = $_POST['cat'];
    $search = "WHERE id_category='$cat'";
}