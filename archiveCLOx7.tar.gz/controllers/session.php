<?php
if (session_status() == PHP_SESSION_ACTIVE) {	    //Checks if session started or not
} else {
    ini_set('session.cookie_lifetime', 60 * 60 * 24 * 100);
    ini_set('session.gc_maxlifetime', 60 * 60 * 24 * 100);
    session_start();
}
if ( (isset($_SESSION['username']) && $_SESSION['password']) ){
    $smarty->assign("user", $_COOKIE['Authenticated']);
    $smarty->assign("userID", $_COOKIE['user_id']);
    $smarty->assign("cart", $_SESSION['cart']);
    $smarty->assign("cartTotal", $_SESSION['cartTotal']);

}
/*if (isset($_GET['changeLang'])){
    $_SESSION['curLang'] = $_GET['changeLang'];
    $url= "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    $url = strtok($url, '?');
    echo $url;
    header("Location: $url");
}
$q = mysqli_query($GLOBALS['conn'], "SELECT * FROM settings WHERE id='1'");
$row = mysqli_fetch_assoc($q);
if ($row['multiLang'] == '1'){
    $smarty->assign("multiLang", "Enabled");
} else {
    $_SESSION['curLang'] = 'ru';
    $lang = $_SESSION['curLang'];
}

if (isset($_SESSION['curLang'])){
    $lang = $_SESSION['curLang'];
} else {
    $_SESSION['curLang'] = 'ru';
    $lang = $_SESSION['curLang'];
}
$lang_dir = $_SERVER["DOCUMENT_ROOT"]."/templates/default/lang/$lang.conf";
$item_lang_dir = $_SERVER["DOCUMENT_ROOT"]."/templates/default/lang/".$lang."items.conf";
$cat_langs = $_SERVER["DOCUMENT_ROOT"]."/admin/cat.conf";
$prod_langs = $_SERVER["DOCUMENT_ROOT"]."/admin/prod.conf";
$smarty->assign("item_lang", $item_lang_dir);
$smarty->assign("lang", $lang_dir);
$smarty->assign("catLang", $cat_langs);
$smarty->assign("prodLang", $prod_langs);*/
//echo $lang_dir."<br>".$item_lang_dir;
if (isset($_GET['logout'])){
    session_start();
    setcookie("Authenticated", $_COOKIE['Authenticated'], time() - 3600, "/");
    setcookie("user_id", $_COOKIE['user_id'], time() - 3600, "/");
    header('Location: /');
}

?>