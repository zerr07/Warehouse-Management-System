<?php
include_once($_SERVER["DOCUMENT_ROOT"].'/controllers/getLang.php');

function get_tree(){
    global $langID;
    $result = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*categories*} WHERE parent is NULL"));
    if($result){
        $temp = array();
        $arr = array();
        while ($row = $result->fetch_assoc()){
            $id = $row['id'];
            $name = $row['name'];
            $temp[$id] = array("name"=>$name, "parent"=>$row['parent'], "child"=>array());
            $temp[$id]['child'] = get_sub_cat($id);
        }
        return $temp;
    }
    return null;
}
function get_sub_cat($index) {
    global $langID;
    $result = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*categories*} WHERE parent='$index'"));
    if($result){
        while ($row = $result->fetch_assoc()){
            $id = $row['id'];
            $name = $row['name'];
            $temp[$id] = array("name"=>$name, "parent"=>$row['parent'], "child"=>array());
            $temp[$id]['child'] = get_sub_cat($id);
        }
        return $temp;
    }
    return null;
}
function get_categories(){
    $arr = array();
    $result = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "SELECT * FROM {*categories*}"));
    if($result){
        while ($row = $result->fetch_assoc()){
            $arr[$row['id']] = $row;
        }
    }
    return $arr;
}