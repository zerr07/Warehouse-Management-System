<?php
$searchQuery = "";
$arr = array(array());
$desc = array(array());
if (isset($_POST['searchArve'])){
    $arve = $_POST['searchArve'];
    $searchQuery = "WHERE arveNr LIKE '%$arve%'";
}
if (isset($_GET['view'])){
    $view = $_GET['view'];
    $searchQuery = "WHERE id='$view'";
}
$q = mysqli_query($GLOBALS['conn'], "SELECT * FROM SMTsales $searchQuery ORDER BY saleDate DESC");
for ($i = 0;$row = mysqli_fetch_assoc($q); $i++){
    $arr[$i]['arveNr'] = $row['arveNr'];
    $arr[$i]['date'] = date_format(date_create($row['saleDate']), "d.m.Y H:i:s");
    $arr[$i]['sum'] = number_format($row['cartSum'], 2);
    $arr[$i]['card'] = number_format($row['card'],2);
    $arr[$i]['cash'] = number_format($row['cash'],2);
    $arr[$i]['id'] = $row['id'];
    $arr[$i]['ostja'] = $row['ostja'];
    $arr[$i]['tellimuseNr'] = $row['tellimuseNr'];
    $arr[$i]['mode'] = $row['modeSet'];
    $arr[$i]['tagastusFull'] = "";
    $id = $row['id'];
    $countTagastus = 0;
    $countItems = 0;
    $qItems = mysqli_query($GLOBALS['conn'], "SELECT * FROM SMTsoldItems WHERE saleID='$id'");
    while ($rowItems = mysqli_fetch_assoc($qItems)){
        $arr[$i]['tagastusFull'] .= "tagastusFull[]=".$rowItems['id']."&";
        $desc[$rowItems['id']]['saleID'] = $rowItems['id'];
        $desc[$rowItems['id']]['price'] = number_format($rowItems['price'],2);
        $desc[$rowItems['id']]['quantity'] = $rowItems['quantity'];
        $desc[$rowItems['id']]['basePrice'] = number_format($rowItems['basePrice'], 2);
        $desc[$rowItems['id']]['status'] = $rowItems['statusSet'];
        if ($rowItems['statusSet'] == "Müük"){
            $countTagastus++;
        }
        $countItems++;
        $itemID = $rowItems['itemID'];
        if (is_numeric($itemID)){
            $qItemDesc = mysqli_query($GLOBALS['conn'], "SELECT * FROM SMTitems WHERE id='$itemID'");
            while ($rowItemDesc = mysqli_fetch_assoc($qItemDesc)){
                $desc[$rowItems['id']]['name'] = $rowItemDesc['SMTitemName'];
                $desc[$rowItems['id']]['tag'] = $rowItemDesc['SMTitemTagID'];
                $desc[$rowItems['id']]['id'] = $rowItemDesc['id'];
            }
        } else {
            $desc[$rowItems['id']]['name'] = $itemID;
            $desc[$rowItems['id']]['tag'] = "Buffertoode";
            $desc[$rowItems['id']]['id'] = "";
        }
    }

    if ($countTagastus == $countItems){
        $arr[$i]['status'] = "Müük";
    } elseif ($countTagastus < $countItems && $countTagastus != 0){
        $arr[$i]['status'] = "Müük/Tagastus";
    } elseif ($countTagastus == 0){
        $arr[$i]['status'] = "Tagastus";
    }
}
$count_on_page = 7;
include ($_SERVER["DOCUMENT_ROOT"].'/controllers/pagination.php');
if (isset($_GET['page'])) {
    $randomshit = get_pages($arr, $_GET['page'], $count_on_page,5);
    $smarty->assign("current_page", $_GET['page']);
} else {
    $randomshit = get_pages($arr,1 , $count_on_page,5);
    $smarty->assign("current_page", 1);
}
$smarty->assign("pageBase" , GETLinks("http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}"));
$smarty->assign("pages" , $randomshit);
$arr = get_pagination($arr, $smarty,$count_on_page);
$smarty->assign("sales", array_filter($arr));
$smarty->assign("desc", array_filter($desc));