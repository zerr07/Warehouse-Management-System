<?php
include_once($_SERVER["DOCUMENT_ROOT"] . '/config.php');
function updateCart(){
    if($_SESSION['cart'] != "\"null\"" || $_SESSION['cart'] != "\"[]\""){
        $cart = json_encode($_SESSION['cart']);
        $id = $_COOKIE['user_id'];
        mysqli_query($GLOBALS['conn'], /** @lang text */ "UPDATE users SET cart='$cart' WHERE id='$id'");
    }
}

function getCart($id){
    $result = mysqli_query($GLOBALS['conn'], /** @lang text */ "SELECT cart FROM users WHERE id='$id'");
    while ($row = mysqli_fetch_assoc($result)){
        $_SESSION['cart'] = $row['cart'];
    }
}