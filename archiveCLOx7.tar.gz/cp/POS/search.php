<?php
ini_set("display_errors", "on");
error_reporting(E_ALL ^ E_NOTICE);
include($_SERVER["DOCUMENT_ROOT"]).'/cp/POS/update.php';

include($_SERVER["DOCUMENT_ROOT"]).'/controllers/checkLogin.php';

if (isset($_GET['addID']) && $_GET['addID'] != ""){
    $addID = $_GET['addID'];
}
if (isset($_POST['searchTagID']) && $_POST['searchTagID'] != ""){
    $id = $_POST['searchTagID'];
}
if (isset($_POST['searchName']) && $_POST['searchName'] != ""){
    $name = $_POST['searchName'];
}


if (isset($id) || isset($name) || isset($addID)) {
    if (isset($addID)){
        $q = mysqli_query($GLOBALS['conn'], "SELECT * FROM  SMTitems WHERE id='$addID'");
    } elseif (isset($id) && isset($name)) {
        $q = mysqli_query($GLOBALS['conn'], "SELECT * FROM  SMTitems WHERE SMTitemName LIKE '%" . $name . "%' AND SMTitemTagID='$id'");
    } elseif (isset($id)) {
        $q = mysqli_query($GLOBALS['conn'], "SELECT * FROM  SMTitems WHERE SMTitemTagID='$id'");
    } elseif (isset($name)) {
        $q = mysqli_query($GLOBALS['conn'], "SELECT * FROM  SMTitems WHERE SMTitemName LIKE '%" . $name . "%'");
    }
    $items = array(array());
    while ($row = mysqli_fetch_assoc($q)) {
        if (mysqli_num_rows($q) != 1) {
            array_push($items, $row);

        } else {
            $dbID = $row['id'];
            if (isset($_SESSION['cart'][$row['id']])){
                $_SESSION['cart'][$row['id']]['quantity']++;
            } else {
                $itemID =  $row['id'];
                $_SESSION['cart'][$row['id']]['IMG'] = $row['SMTitemIMG'];
                $_SESSION['cart'][$row['id']]['id'] = $row['id'];
                $_SESSION['cart'][$row['id']]['tag'] = $row['SMTitemTagID'];
                $_SESSION['cart'][$row['id']]['name'] = $row['SMTitemName'];
                $_SESSION['cart'][$row['id']]['quantity'] = 1;
                $_SESSION['cart'][$row['id']]['Available'] = $row['SMTitemQuantity'];
                $queryLoc = mysqli_query($GLOBALS['conn'], "SELECT * FROM SMTlocations WHERE SMTitemID='$itemID'");
                while ($rowLoc  = mysqli_fetch_assoc($queryLoc)){
                    $_SESSION['cart'][$row['id']]['loc'][$rowLoc['id']] = $rowLoc['SMTlocation'];
                }

                $query = mysqli_query($GLOBALS['conn'], "SELECT * FROM SMTplatformsList WHERE itemID='$dbID' AND platformID='1'");
                while ($rowQ = mysqli_fetch_assoc($query)) {
                    $_SESSION['cart'][$row['id']]['price'] = number_format($rowQ['price'], 2);
                    if (is_numeric($rowQ['price'])){
                        $_SESSION['cart'][$row['id']]['basePrice'] = number_format($rowQ['price'], 2);
                    } else {
                        $_SESSION['cart'][$row['id']]['basePrice'] = number_format(0, 2);
                    }
                }
                if (mysqli_num_rows($query) != 1){
                    $_SESSION['cart'][$row['id']]['basePrice'] = number_format(0, 2);
                }
            }
        }
    }
    if (count($items) != 1){
        $items = array_filter($items);
        $smarty->assign("items", $items);
        $smarty->display('cp/POS/search.tpl');
    } else {
        calcCart();
        header('Location: /cp/POS' );
    }
}
if (isset($_GET['clear'])){
    unset($_SESSION['cart']);
    header('Location: /cp/POS' );
}
