<?php
include($_SERVER["DOCUMENT_ROOT"].'/configs/setup.php');
$smarty = new Smarty_startup();
include($_SERVER["DOCUMENT_ROOT"].'/controllers/session.php');

if (isset($_POST['id'])){
    $id1 = $_POST['id'];
    $i = 0;
    foreach ($id1 as $item){
        $_SESSION['cart'][$item]['basePrice'] = number_format($_POST['price'][$i],2);
        $_SESSION['cart'][$item]['quantity'] = $_POST['quantity'][$i];
        $i++;

    }
}
if (isset($_POST['bufferID'])){
    $i = 0;
    foreach ($_POST['bufferID'] as $id2){
        $_SESSION['cart'][$id2]['name'] = $_POST['buffer'][$i];
        $i++;
    }
}
if (isset($_POST['delete'])){
    unset($_SESSION['cart'][$_POST['delete']]);
}
calcCart();
if (isset($_POST['update']) || isset($_POST['delete'])){

    header('Location: /cp/POS' );
}

function calcCart(){

    foreach ($_SESSION['cart'] as $key => $item) {

            $_SESSION['cart'][$key]['price'] = number_format($_SESSION['cart'][$key]['quantity'] * $_SESSION['cart'][$key]['basePrice'], 2);
        }

    $_SESSION['cartTotal'] = 0;

    foreach ($_SESSION['cart'] as $key => $item) {
            $_SESSION['cartTotal'] += $_SESSION['cart'][$key]['price'];
        }

}
