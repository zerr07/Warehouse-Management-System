<html>
<head>
    <style>
        .infoBlock{
            border: 3px solid black;
            padding: 10px;
        }
    </style>
</head>
<body>

<p style="padding-bottom: 50px;">
<b style="float: left">ARVE №15071901 </b>
<b style="float: right">Kuupäev</b>
</p>
<div style="width: 100%; height: 200px">
    <p style="float: left" class="infoBlock">
        <b>Müüja:</b> AZ Trade OÜ<br>
        Reg Nr: 12474341<br>
        Aadress: J. Koorti tn 2-122 Tallinn,Harjumaa 13623<br>
        KMKR: EE101681917
    </p>
    <p style="float: right" class="infoBlock">
        <b>Ostja:</b> SCANDAGRA EESTI AS<br>
        Reg Nr: 10188677<br>
        Aadress: Tähe tn 13 Viljandi Viljandimaa 71012<br>
        Makseviis: kaardimakse
    </p>
</div>
    <p style="float: right">
        <b>Maksetähtaeg: 16.08.2019</b><br>
        Viivis: 0,05%
    </p>
<table style="width: 100%">
    <thead>
    <tr>
        <th>Kood</th>
        <th>Teenuste/kaupade nimetus</th>
        <th>Ühik Maht</th>
        <th>Hind KM-ga</th>
        <th>Hind KM-ta</th>
        <th>Kokku</th>
    </tr>
    </thead>
</table>

</body>
</html>