<?php
include($_SERVER["DOCUMENT_ROOT"] . '/configs/config.php');
session_start();
$catName = $_POST['catName'];
$catParent = $_POST['cat'];
if ($catParent == 'None'){
    $result = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "INSERT INTO  {*categories*} (`name`) 
                                                                                            VALUES ('$catName')"));
} else {
    $result = $GLOBALS['DBCONN']->query(prefixQuery(/** @lang text */ "INSERT INTO  {*categories*} 
                                                                (`name`, parent) VALUES ('$catName', '$catParent')"));
}
header("Location: /cp/SupplierManageTool/");